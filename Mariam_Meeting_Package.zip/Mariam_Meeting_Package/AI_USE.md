# AI use and contribution record

## Scope

ChatGPT generated the standalone capture-quality policy, evaluation scripts, test suite,
offline replay/review screens, integration example and documentation during this session.
Mariam supplied project context, requirements, archived recordings, team deliverables and
Discord exports, and authorized building the module. Human review and live deployment
have not been performed by this build.

## User prompt authorizing this implementation

> ok perfect. lets do it rn. i am also able to acess the website rn even tho i am not in the lab. but lets create this so i can finish it and forget abotu it until next quarter

The preceding assistant proposal defined image acceptance/retake decisions, bounded
retries, archived-data evaluation, human review and later physical validation.
The user subsequently supplied the live imaging URL. This browser could not access it.
Read-only repository inspection was used to document an integration point instead.

This record covers the present implementation. Earlier color-monitoring experiments
are a different exploratory artifact and their results are not reused as proof of this
module. The complete earlier conversation/prompts should be retained separately if
required by the course's full AI-use appendix rules.

## Testing performed

1. V1 used illumination and relative edge checks. It missed nine noisy-blur challenge
   inputs because noise inflated the edge score.
2. A fine-residual guard was added after inspecting that failure. Development data were
   reused, so V2 development results are explicitly labeled accordingly.
3. V2 was frozen and evaluated on nine additional crops from the same recordings with
   changed perturbation settings. All 27 control and 45 injected-fault cases matched
   their transform-defined expected labels. This is computational evaluation, not
   independent physical validation or confirmed biological image quality.
4. Scripted sequences tested bounded recovery and persistent-failure escalation.
5. Eleven behavioral unit tests passed. Offline HTML replay/review JavaScript behavior
   was checked in an isolated DOM stub. Full browser rendering was not verified.
6. Unmodified archived inputs were screened. No human labels or human accuracy figures
   were generated. The review screen requires explicit reviewer input.

## Work Mariam should record

Record when you reproduced the code, the cases you inspected, your review labels,
decisions about reference/ROI/thresholds, corrections you made, team scope coordination
and mentor feedback. Do not claim AI-prepared code as unaided work or present planned
physical tests as completed. Add actual review and integration outcomes as they happen.

## Evaluation priority revision

At the user request, original captured images are the primary evaluation. Artificial
blur, darkness and noise remain supporting software stress tests. The standalone
Drive image is excluded from primary metrics until exact prototype attribution is
confirmed. Human source confirmation and review labels remain user inputs.

## Additional supplied material and applicability review

The user supplied two organoid ZIPs, website screenshots, a personal research proposal
and a course orientation. ChatGPT inventoried 18 images from 2023 and 20 from 2024,
measured them without simulated fault injection, preserved file hashes and processing
notes, and generated a separate cohort-based human review tool. No image-quality or
health labels were invented. A reference is not automatically selected. The interface
withholds a full decision without suitable reviewer-confirmed references. Rectangular
image analysis now preserves aspect ratio. Existing square-image metrics were verified
unchanged and twelve behavioral tests passed. Scope documentation identifies shared
work and does not claim chronology or exclusive ownership from an undated proposal.

## November 24 original-file update

The user supplied nine recent prototype date ZIPs and a ZIP described as 40 original
organoid images. Inspection found 606 distinct original prototype JPEGs and 20 original
2024 JPGs, test21-test40. ChatGPT inventoried files, measured source-image features,
created a fixed 48-image date/well-stratified review set without consulting scores,
checked 20 original/corrected pairs, and generated separate review/report views.
448 low-light flags are provisional component results, not verified accuracy. No human
labels, physical retakes, movement-stop times or health labels were fabricated. Existing
preprocessing is attributed to its supplied source. Original low-quality images are
retained for evaluation. Twelve core tests passed after this update.
