# One design, two separate image evaluations

## Proposed individual scope

Image-acquisition quality acceptance, bounded retake requests and experimental evaluation.
The primary data are original current-prototype bead captures. The archival organoid
cohorts are an exploratory applicability study for the intended future subject.
They do not establish current-prototype organoid capture or biological health.

## Connection to the uploaded proposal

Page 4, section F, "Solution 4: Image Quality and AI Detector Reliability," explicitly
proposes an automated quality gate for brightness, saturation, focus/blur, contrast
and gross field-of-view displacement, followed by reacquisition if an image fails.
Section E also discusses settling intervals, vibration and image-capture timing.
This directly supports continuity with that uploaded proposal. The PDF alone does
not establish its original creation/submission date, who conceived an idea first,
mentor approval or exclusive ownership.

Implemented now: illumination/saturation checks, reference-relative edge proxy,
fine-residual guard, bounded retry decisions, per-attempt logs and offline evaluation.
Not implemented/validated: hardware illumination repair, actual autofocus, gross
field displacement checking, a separately validated contrast criterion, a physically
optimal settling delay, health prediction or live deployment. The existing scanner
already waits after movement. Preserve and coordinate with that implementation.
The proposal described one reacquisition; this software demonstration currently uses
three total attempts. That is configurable and has not been physically optimized.

## Evidence from the course orientation

The uploaded orientation asks individual task updates to present methods, labeled
data/figures, findings and next steps, followed by discussion of limitations. Its
Fall table emphasizes design, prototyping and experimental results; the Winter
table describes applying the prototype to organoid culture. This supports a staged
validation plan. Some slides retain older year labels, so this is broad guidance,
not proof of the current grading rubric or a guarantee of acceptance.

## Existing work and overlap

| Area | Existing evidence | Boundary for this deliverable |
|---|---|---|
| LED hardware | Assigned to Ricki and others | Do not claim the LED installation as new work in this software module |
| Training data and annotations | Ricki/Amy/others; intact/fragment labels requested | Quality review evaluates acquisition decisions; it does not replace their biological annotations |
| Image-quality definitions | Ricki explicitly proposed shared criteria on October 14 | Coordinate criteria; do not claim exclusive ownership of the general concept |
| Scanning, stage movement and saved focus height | Visible UI and team records | Add acceptance output at an agreed interface; preserve their navigation and timing work |
| Camera timeouts/recovery | Present in reviewed camera source | This module checks received image content; it does not replace or claim the watchdog |
| Model-driven motor control | Assigned to Nick | Coordinate any automated corrective action before integration |
| Segmentation and classification | Assigned to Ricki/Amy/others | No new organoid segmentation or health model is claimed |
| Growth analytics and detection | Visible in website screenshots | No growth/health analytics are claimed as this new feature |

The screenshots do not display an explicit image-acceptance score/retake result.
The reviewed main-branch capture function requests/encodes/stores frames but does
not contain this proposed image-content policy. Neither observation proves that
another branch, a deployed version or a teammate's private work lacks one. Final
individual ownership needs coordination with the relevant contributors.

## Evaluation A: recent original prototype files

The active primary set is 606 distinct original 1024x1024 JPEGs from nine supplied
November 13-22 date archives. Eight archives are nonempty. November 18 contains no
image files; November 22 contains one. No Nov 17 archive was supplied. File counts
are not uptime or missing-image-rate measurements.

448/606 fall below the pre-existing mean-gray threshold of 20/255. That is a
provisional illumination flag count, not confirmed unusability or accuracy. The
remaining 158 images still need reference context for full detail checks. A seeded
48-image date/well-stratified review set is fixed before human labeling. Human
quality labels remain empty. The old 85 video samples are supporting historical data.

## Evaluation B: archival organoid applicability and paired processing

The 2023 cohort contains 18 as-provided RGB PNGs, 800x600. The newest 2024 ZIP contains
20 original RGB JPGs, test21-test40, 4056x3040. Twenty supplied corrected grayscale
versions match those original scenes. Names, dimensions and band-pass image similarity
support the 20 pairs. They are not 40 independent scenes.

The median paired mean-gray increase is +57.6/255 levels. Processing changes the
measurements without a new physical capture; this does not demonstrate refocusing,
health, true capture improvement or successful reacquisition. Exact processing
provenance is unverified. Review the original 2024 cohort and the 2023 cohort separately.
Keep corrected versions as a paired comparison. Do not claim existing preprocessing
as this module's new contribution.

No matched physical focus standards or human quality labels were supplied. The review
requires explicit quality labels and optional verified references, excluded from its
evaluation denominator. Without suitable references, full checks remain unavailable.
Year alone does not establish matching acquisition settings or field context. Biological
intact/fragment annotation and health evaluation are separate tasks.

## Quantitative claims allowed now

Available: source counts/dimensions/modes/hashes, descriptive image measurements,
provisional screening counts, computational stress-test outcomes and behavior tests.
Pending: agreement with human labels, confirmed prototype attribution, meaningful
organoid reference selection, physical retake success and settling-time measurements.
Do not describe pending results as completed because the software exists.

## Design choices and alternatives

Fixed waiting addresses some post-move blur but cannot identify a dark image.
Correction alone may improve uneven illumination but cannot guarantee usable focus.
A reference-aware acceptance policy with bounded retries adds explicit capture
verification while exposing persistent faults for review. It depends on suitable
references and can be affected by scene content, noise and real fine texture.
Those are testable constraints, not problems assumed solved.

## Next-quarter handoff

Agree on owner/interface with Ricki, Amy, Nick and the acquisition team. Verify
references and logging, connect the adapter, test controlled stationary bead captures
after real moves, then evaluate images of organoids on the current prototype.
Report added acquisition time and physical recovery rate. Keep a tested fallback
and manual intervention path. Do not change hardware or deploy untested code merely
to claim integration before the meeting.
