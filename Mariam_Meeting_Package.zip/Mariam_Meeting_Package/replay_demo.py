"""Execute the controller on a simulated retry sequence from a real camera crop."""
from pathlib import Path
import argparse,json
from capture_quality import *

ROOT=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--scenario',choices=['recovery','persistent_failure','missing_then_recovery'],default='recovery')
    p.add_argument('--output',type=Path,default=ROOT/'results'/'last_demo_log.json')
    args=p.parse_args()
    reference=load_rgb(ROOT/'demo_images'/'unchanged.png')
    blur=load_rgb(ROOT/'demo_images'/'blur_radius3.png')
    dark=load_rgb(ROOT/'demo_images'/'dark_gain0.02.png')
    frames={'recovery':[blur,reference],'persistent_failure':[dark]*3,
            'missing_then_recovery':[None,blur,reference]}[args.scenario]
    stream=iter(frames)
    accepted,history=run_capture_cycle(lambda:next(stream),reference,'demo/'+args.scenario)
    for row in history:
        print(f'Attempt {row["attempt"]}: {row["decision"]} '+', '.join(row['reasons']))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    save_log(args.output,history)
    print('Accepted frame available:',accepted is not None)
    print('Saved log:',args.output)
if __name__=='__main__':main()
