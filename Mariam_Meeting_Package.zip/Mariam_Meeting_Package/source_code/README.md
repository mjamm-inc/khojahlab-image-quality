# Image acquisition quality: current study

## Open first

Unzip the package and open START_HERE.html in Chrome. It links to:

* REVIEW_REAL_IMAGES.html: the current primary review of 606 recent prototype files,
  with a fixed 48-image date/well-stratified quick set. REVIEW_RECENT_BEADS.html is
  the same current review. It replaces the older 20-video-frame quick set.
* REVIEW_ORGANOIDS.html: 18 as-provided 2023 images and 20 original 2024 images.
* VIEW_ORGANOID_PAIRS.html: 20 original/corrected 2024 pairs, kept as paired versions.
* CONTROLLER_STRESS_REPLAY.html: supporting computational replay, not physical retakes.
* Mariam_Acquisition_Deliverable.pdf: current source counts, findings and boundaries.

The older 85 video samples and their review remain historical comparison data in
REVIEW_OLDER_VIDEO_FRAMES.html. They are no longer the primary dataset.

## What has been measured

606 distinct original JPEGs, all 1024x1024, were received in nine Nov 13-22 archives.
Eight archives contain images. Nov 18 contains no image files; Nov 22 contains one.
No Nov 17 archive was supplied. These are file-availability facts, not uptime or proof
of failed acquisition. All file hashes and decoded-pixel hashes are distinct, but
repeated captures are correlated and are not independent physical experiments.

448/606 (73.9%) are below the existing mean-gray threshold of 20/255. This is a
provisional illumination-screen count, not detection accuracy or confirmed unusability.
The remaining 158 files are not automatically accepted. Relative detail checks require
a suitable reference with verified matching acquisition conditions. Day/well grouping
helps organize references but does not prove conditions were constant.

The newest organoid ZIP contains 20 original RGB JPGs, test21.jpg through test40.jpg,
not 40 original files. They pair with the 20 supplied corrected grayscale PNGs. Names,
dimensions and image-pattern similarity support those matches. They are 20 scenes
with two versions, not 40 independent scenes. Raw originals and corrected versions
are not pooled into one accuracy denominator. The 18-image 2023 cohort stays separate.

Median paired change in image mean-gray was +57.6/255 levels. That describes processing;
it does not prove improved focus, health or acquisition. Exact processing provenance is
unverified. This module does not claim the supplied preprocessing as its own contribution.

## Complete the current prototype review

1. Open REVIEW_REAL_IMAGES.html and enter your name and source confirmation.
2. Label the quick set Good, Bad or Unsure for technical target visibility. Add a note
   such as too dark, blurred, adequate outlines or uncertainty. Do not label health.
3. If suitable reference images exist, record them and verify their matching conditions.
   Leave references unset where uncertain. Explicit calibration references are excluded.
4. Export Mariam_Recent_Bead_Review.json before closing the page.
5. Run `python3 evaluate_recent_bead_review.py /path/to/Mariam_Recent_Bead_Review.json`
   or supply that JSON for further analysis.

The screen separates illumination-component agreement from the full reference-aware
policy, and records unavailable references and Unsure labels. It cannot calculate
accuracy for unreviewed images. The 48-image quick set is exploratory stratified
sampling, not a random independent validation sample. Finish labels before inspecting
predictions. The static PDF will not automatically incorporate your exported labels.

For the organoid study, label quality separately in each cohort and export the organoid
review JSON. Full checks require suitable references, not bead references. Use
`python3 evaluate_organoid_review.py /path/to/Mariam_Organoid_Quality_Review.json`.

## Reproduce the software

Python 3.10+; install core dependencies with
`python3 -m pip install -r requirements.txt`.

Run the controller and behavioral tests from this folder:

```
python3 replay_demo.py --scenario recovery
python3 replay_demo.py --scenario persistent_failure
python3 replay_demo.py --scenario missing_then_recovery
python3 -m unittest discover -s tests -v
```

Twelve behavioral tests passed after this update. Review controls were checked in an
isolated JavaScript DOM stub. Full browser rendering was not verified in this runtime.
No actual user review labels were generated during tests.

Reproduce recent ZIP measurements:

```
python3 inspect_recent_beads_source.py --archives /path/to/folder/containing/date_zips --output recent_bead_source_cache
```

This preserves original bytes and produces the source inventory, numeric features,
summary and inspection sheet. It uses the supplied archive naming convention.
The delivered current measurement table is results/recent_bead_measurements.csv.

Reproduce archival original/corrected measurements (replace paths with your ZIP paths):

```
python3 prepare_organoid_data.py --zip2023 /path/to/2023.zip --zip2024 /path/to/corrected2024.zip --original2024 /path/to/Organoid_images.zip
python3 analyze_organoid_pairs.py --original-directory source_cache/2024_original --corrected-directory source_cache/2024
python3 build_organoid_review.py
```

Current review and paired-viewer builders:

```
python3 build_recent_bead_review.py
python3 build_current_study.py
```

The recent builder emits REVIEW_RECENT_BEADS.html. The delivered REVIEW_REAL_IMAGES.html
is an alias copy for continuity with earlier download instructions. Full originals are
not duplicated in this package. Keep the uploaded ZIPs as the authoritative input data.
Previews are display derivatives; measurement tables retain original IDs and hashes.

For PDF/figure generation, install requirements-report.txt and run build_current_report.py.
Historical builders build_deliverable.py and build_summary.py describe the previous
video-based study and should not replace the current entry point/report.

## Scope, integration and limitations

The core supports illumination, relative edge strength, a fine-residual guard, bounded
attempts and per-attempt logging. It does not move motors, adjust focus, repair lighting,
restart the server, infer biological health or select an optimal physical settling delay.
A fresh-capture callback must have its own timeout. The budget is not hard real-time.

The existing scanner already owns motion, waits after movement, and camera recovery.
An integration example is supplied, but no live code has been changed. Reference
selection, persistent quality logs and deployed behavior need verification with the team.
Images named by capture time do not provide movement-stop timing for a settling study.

DESIGN_SCOPE_AND_EVIDENCE.md maps the proposal and shared team work. Source notebooks
exist in the connected repository, but its current tree contains no standalone image
files; an inspected notebook uses local paths. Embedded comparison figures are not
substitutes for original or corrected image files.

AI assistance and contribution boundaries are documented in AI_USE.md. Mariam must
reproduce, inspect and explain the work, supply real review labels, and record her own
decisions. Coordinate scope with existing contributors and confirm the Fall deliverable
with the mentor. Do not present supporting computational tests as physical validation.
