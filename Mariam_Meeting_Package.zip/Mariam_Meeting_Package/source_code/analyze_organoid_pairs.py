"""Descriptive paired analysis of supplied original and corrected 2024 images.
No quality/health improvement is inferred. Matching by name is supported by
dimensions and relative band-pass image similarity, not assumed from numbering alone.
"""
from pathlib import Path
import argparse,csv,json,re
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
ROOT=Path(__file__).resolve().parent

def vector(path):
    with Image.open(path) as im:
        g=np.asarray(im.convert('L').resize((512,384),Image.Resampling.LANCZOS),dtype=float)
    band=gaussian_filter(g,1)-gaussian_filter(g,8)
    v=band.ravel();v=v-v.mean()
    return v/max(np.linalg.norm(v),1e-12)

def main():
    p=argparse.ArgumentParser();p.add_argument('--original-directory',type=Path,required=True);p.add_argument('--corrected-directory',type=Path,required=True);args=p.parse_args()
    raw=[x for x in json.loads((ROOT/'results/organoid_inventory_metrics.json').read_text()) if x['year']=='2024']
    corrected=json.loads((ROOT/'results/organoid_corrected_inventory_metrics.json').read_text())
    raw.sort(key=lambda x:x['id']);corrected.sort(key=lambda x:x['id'])
    corr_map={re.match(r'(test\d+)',Path(x['id']).stem).group(1):x for x in corrected}
    raw_vec=[vector(args.original_directory/Path(x['id']).name) for x in raw]
    corr_vec=[vector(args.corrected_directory/Path(x['id']).name) for x in corrected]
    similarities=np.asarray(raw_vec)@np.asarray(corr_vec).T
    pairs=[]
    for i,a in enumerate(raw):
        key=re.match(r'(test\d+)',Path(a['id']).stem).group(1)
        b=corr_map.get(key)
        if b is None:continue
        if (a['width'],a['height'])!=(b['width'],b['height']):raise ValueError('Pair dimensions mismatch')
        j=next(j for j,x in enumerate(corrected) if x['id']==b['id'])
        m=a['metrics'];n=b['metrics']
        pairs.append(dict(pair=key,original_id=a['id'],corrected_id=b['id'],original_sha256=a['sha256'],corrected_sha256=b['sha256'],
                          bandpass_similarity=float(similarities[i,j]),same_name_is_highest_similarity=bool(np.argmax(similarities[i])==j),
                          original_mean=m['mean_gray'],corrected_mean=n['mean_gray'],mean_change=n['mean_gray']-m['mean_gray'],
                          original_normalized_edge=m['normalized_edge'],corrected_normalized_edge=n['normalized_edge'],
                          normalized_edge_change=n['normalized_edge']-m['normalized_edge'],original_preview=a['preview'],corrected_preview=b['preview']))
    with (ROOT/'results/organoid_2024_paired_measurements.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
    (ROOT/'results/organoid_2024_pairs.json').write_text(json.dumps(pairs,indent=2))
    summary=dict(originals_received=len(raw),corrected_files=len(corrected),pairs=len(pairs),
                 same_name_is_highest_similarity=sum(x['same_name_is_highest_similarity'] for x in pairs),
                 original_median_mean=float(np.median([x['original_mean'] for x in pairs])),
                 corrected_median_mean=float(np.median([x['corrected_mean'] for x in pairs])),
                 median_paired_mean_change=float(np.median([x['mean_change'] for x in pairs])),
                 bandpass_similarity_range=[min(x['bandpass_similarity'] for x in pairs),max(x['bandpass_similarity'] for x in pairs)],
                 scope='Descriptive paired processing comparison. Does not establish improved focus, organoid health, native acquisition quality, or physical retake success. Exact processing provenance is unverified.')
    (ROOT/'results/organoid_2024_paired_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
