"""Current report: recent original bead captures and paired archival organoid inputs."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import reportlab
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parent
def main():
    s=json.loads((ROOT/'results/recent_bead_summary.json').read_text());pair=json.loads((ROOT/'results/organoid_2024_paired_summary.json').read_text())
    days=[r['archive'][:10] for r in s['archive_counts']];counts=[r['image_files'] for r in s['archive_counts']]
    flags=[s['by_day'].get(d,{}).get('low_light_flags',0) for d in days]
    fig,ax=plt.subplots(figsize=(8,2.6),layout='constrained');x=list(range(len(days)))
    ax.bar(x,[n-f for n,f in zip(counts,flags)],color='#167a78',label='No illumination flag (not full acceptance)')
    ax.bar(x,flags,bottom=[n-f for n,f in zip(counts,flags)],color='#a8526a',label='Below mean-gray threshold 20/255')
    for i,(n,f) in enumerate(zip(counts,flags)):ax.text(i,n+3,f'{f}/{n}' if n else 'No files',ha='center',fontsize=8)
    ax.set_xticks(x,[d[5:] for d in days]);ax.set_xlabel('Supplied archive date, November 2026');ax.set_ylabel('Original image files');ax.set_ylim(0,190);ax.spines[['top','right']].set_visible(False);ax.legend(fontsize=7,loc='upper left',frameon=False)
    ax.set_title('Primary data: low-light flags on original prototype images',loc='left',fontsize=11)
    fig.savefig(ROOT/'results/recent_bead_flags_by_day.png',dpi=180);plt.close(fig)
    fontdir=Path('/usr/share/fonts/truetype/dejavu');normal=fontdir/'DejaVuSans.ttf';bold=fontdir/'DejaVuSans-Bold.ttf'
    if not normal.exists():normal=Path(reportlab.__file__).parent/'fonts/Vera.ttf';bold=normal.with_name('VeraBd.ttf')
    pdfmetrics.registerFont(TTFont('CurrentBody',str(normal)));pdfmetrics.registerFont(TTFont('CurrentBold',str(bold)));pdfmetrics.registerFontFamily('CurrentBody',normal='CurrentBody',bold='CurrentBold',italic='CurrentBody',boldItalic='CurrentBold')
    styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='B',fontName='CurrentBody',fontSize=9.4,leading=13,spaceAfter=8));styles.add(ParagraphStyle(name='S',fontName='CurrentBody',fontSize=8,leading=10.5,spaceAfter=7,textColor=colors.HexColor('#526976')))
    styles['Title'].fontName='CurrentBold';styles['Title'].fontSize=22;styles['Title'].leading=26;styles['Title'].alignment=0;styles['Heading2'].fontName='CurrentBold';styles['Heading2'].fontSize=12;styles['Heading2'].leading=16;styles['Heading2'].textColor=colors.HexColor('#126865')
    def p(t,small=False):return Paragraph(t,styles['S' if small else 'B'])
    def h(t):return Paragraph(t,styles['Heading2'])
    def table(data,widths=[225,275]):
        t=Table([[p(c) for c in row] for row in data],colWidths=widths,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5f0f0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.4,colors.HexColor('#d4dfe5')),('LEFTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),3)]));return t
    story=[p('MARIAM JAMMAL / FALL 2026 / CURRENT DATA UPDATE',True),Paragraph('Image acceptance and<br/>bounded retake requests',styles['Title']),
           p('One acquisition-quality module, evaluated primarily on recent original prototype images and separately on archival organoid imagery. Software decisions are not organoid-health assessments.'),h('Primary dataset: November 13-22 original files'),
           table([['<b>Item</b>','<b>Measured result / status</b>'],['Original prototype images','606 JPEG files, all 1024x1024'],['Distinctness','606 distinct file hashes and 606 distinct decoded-pixel hashes'],['Existing low-light criterion','448/606 (73.9%) below mean-gray 20/255'],['Remaining 158 images','No illumination flag; full acceptance is not established'],['Human-reviewed performance','Pending actual labels and suitable reference context']]),Spacer(1,8),Image(str(ROOT/'results/recent_bead_flags_by_day.png'),width=500,height=162),
           p('The November 18 archive contains no image files. November 22 contains one. No November 17 archive was supplied. These facts describe the uploaded files, not system uptime or proof of missing acquisitions.',True),
           h('What must be verified next'),p('Review the fixed 48-image date/well-stratified set in REVIEW_REAL_IMAGES.html, or the full 606 files. Illumination-screen agreement is separate from the full reference-aware policy. Full acceptance of adequately illuminated images requires a suitable matched reference. References are not transferred across days/wells by assumption.'),
           p('The threshold predates these archives and has not been tuned on their human labels. The 448 flags are provisional screening results, not 448 confirmed unusable images or a detection-accuracy percentage. Files and repeated timepoints are correlated; 606 files are not 606 independent physical experiments.',True),PageBreak(),
           Paragraph('Archival organoid applicability',styles['Title']),h('Original and corrected inputs kept separate'),
           table([['<b>Dataset</b>','<b>Available material</b>'],['2023 organoid cohort','18 as-provided RGB PNGs, 800x600; prior processing unconfirmed'],['2024 originals received','20 RGB JPGs: test21.jpg through test40.jpg, 4056x3040'],['2024 corrected versions','20 grayscale PNGs, 4056x3040, supplied previously'],['Paired scenes','20 original/corrected pairs; not 40 independent scenes']]),
           p('Filename and dimension matching support 20 pairs. For each original, its same-numbered corrected file was also the highest band-pass similarity match among the supplied corrected images. Similarity supports the pairing; it does not establish biological equivalence or exact processing provenance.'),h('Descriptive paired measurement'),
           p(f'Median image mean-gray was {pair["original_median_mean"]:.1f}/255 in originals and {pair["corrected_median_mean"]:.1f}/255 in corrected versions. Median paired change was +{pair["median_paired_mean_change"]:.1f} levels. These quantities differ from each other mathematically: the median paired change need not equal the difference of the two medians.'),
           p('Processing changes pixel measurements without a new physical capture. Increased brightness or a different edge score does not prove improved focus, organoid health or acquisition success. The corrected versions are a supplied comparison condition, not preprocessing work claimed by this module.'),h('Organoid review and repository check'),
           p('REVIEW_ORGANOIDS.html now evaluates the 2023 cohort and original 2024 images separately. VIEW_ORGANOID_PAIRS.html shows the corresponding corrected versions. Human quality labels start empty. Full gate decisions need reviewer-confirmed appropriate references; otherwise the tool reports reference requirements and exports measurements without inventing acceptance.'),
           p('The connected main-branch repository contains preprocessing notebooks but no standalone PNG/JPG images in its recursive file tree. The inspected 2024_processing.ipynb example references local Windows input/output paths and processes a 2023 image. An embedded comparison figure is not a substitute for source image files. The exact method used for the supplied corrected 2024 images is therefore not assumed.'),
           p('These archival organoid images do not establish organoid capture by the current prototype. Biological intact/fragment labels, segmentation accuracy and health prediction remain separate from technical image quality.',True),PageBreak(),
           Paragraph('Design continuity and validation plan',styles['Title']),h('Documented connection and scope'),
           p('The uploaded proposal, page 4, Solution 4, explicitly proposes automated image-quality checks with reacquisition. Section E discusses vibration and settling intervals. This module implements a bounded part of that proposal. The PDF alone does not establish its original submission date or exclusive ownership.'),
           p('The orientation calls for individual task updates with methods, labeled data/figures, findings and next steps. Its Fall table emphasizes design/prototyping and experimental results, followed by organoid application in Winter. Some slides retain older year labels, so the document is broad guidance rather than proof of the current grading rubric.'),h('Existing work and individual contribution'),
           p('Existing autofocus, scanning, stage controls, image preprocessing, watchdog recovery, cloud storage, growth analytics and biological classification remain attributed to their contributors. The proposed individual contribution is the specific image-content acceptance policy and its quantitative evaluation at an agreed acquisition interface. Shared quality criteria and integration require coordination.'),
           p('The reviewed main-branch capture function does not contain this proposed image-content policy. Screenshots do not show an explicit acceptance/retake output. Neither observation rules out another branch, deployed changes or private work in progress.'),h('Completed software work'),
           p('The core supports illumination, reference-relative edge strength and fine-residual checks, bounded attempts and per-attempt logs. Prior computational stress tests and scripted sequences exercise specified failures, cancellation and time limits. They remain supporting results; no simulated case is presented as an original prototype capture. Twelve core behavioral tests passed after this data update, including rectangular-image handling.'),h('Finish the real-data evaluation'),
           p('Use explicit Good/Bad/Unsure labels for technical target visibility. Report missed bad images, unnecessary flags, agreement and reference-unavailable cases on the actual reviewed subset. Keep the recent bead set, archival organoid cohorts and processed-image comparisons separate. Preserve settings before review; later tuning needs separate validation data.'),
           p('Next-quarter physical work includes matched reference validation, agreed scanner integration, stationary-target captures after known stage moves, actual settling-delay measurements, retake success and added time per well. Saved time-series filenames do not supply stage-stop timing and cannot establish an optimal capture delay.'),
           p('<b>AI assistance:</b> ChatGPT prepared implementation, computational tests, image inventory/measurements, review tools and documentation. Mariam must reproduce and explain the work, supply actual review labels, document her design choices and coordinate ownership. No live scanner or hardware was changed.',True)]
    def footer(c,d):c.setFont('CurrentBody',8);c.setFillColor(colors.HexColor('#617782'));c.drawString(48,28,'Original-image evaluation / human review and physical validation pending');c.drawRightString(552,28,str(d.page))
    doc=SimpleDocTemplate(str(ROOT/'Mariam_Acquisition_Deliverable.pdf'),pagesize=(612,792),leftMargin=48,rightMargin=48,topMargin=40,bottomMargin=44,title='Mariam - Current Acquisition Quality Evaluation',author='Prepared for Mariam Jammal with ChatGPT assistance');doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print('Built current recent-data report and figure.')
if __name__=='__main__':main()
