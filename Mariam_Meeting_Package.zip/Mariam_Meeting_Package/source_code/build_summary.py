"""Create the two-page engineering summary and exportable quantitative figure."""
from pathlib import Path
import json
import reportlab
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
def main():
    font_dir=Path('/usr/share/fonts/truetype/dejavu')
    normal=font_dir/'DejaVuSans.ttf';bold=font_dir/'DejaVuSans-Bold.ttf'
    if not normal.exists():
        normal=Path(reportlab.__file__).parent/'fonts'/'Vera.ttf'
        bold=normal.with_name('VeraBd.ttf')
    pdfmetrics.registerFont(TTFont('BodySans',str(normal)))
    pdfmetrics.registerFont(TTFont('BodySansBold',str(bold)))
    pdfmetrics.registerFontFamily('BodySans',normal='BodySans',bold='BodySansBold',italic='BodySans',boldItalic='BodySansBold')
    f=json.loads((ROOT/'results'/'followup_summary.json').read_text())
    archive=json.loads((ROOT/'results'/'archive_review.json').read_text())
    primary=[r for r in archive if r['id']!='nov21_camera.jpg']
    names=list(dict.fromkeys(r['source'] for r in primary))
    passed=[sum(r['gate_pass'] for r in primary if r['source']==name) for name in names]
    flagged=[sum(not r['gate_pass'] for r in primary if r['source']==name) for name in names]
    fig,ax=plt.subplots(figsize=(8,2.5),layout='constrained')
    ax.bar(range(4),passed,color='#167a78',label='Passes configured checks')
    ax.bar(range(4),flagged,bottom=passed,color='#a8526a',label='Flagged for review')
    for i,(n,m) in enumerate(zip(passed,flagged)):ax.text(i,n+m+.6,f'{m}/{n+m} flagged',ha='center',fontsize=10)
    ax.set_ylim(0,max(n+m for n,m in zip(passed,flagged))*1.3)
    ax.set_xticks(range(4),['Recording 1','Recording 2','Recording 3','Recording 4'])
    ax.set_ylabel('Sampled frames');ax.spines[['right','top']].set_visible(False)
    ax.legend(loc='upper left',fontsize=8,frameon=False)
    ax.set_title('Primary data: original captures, without injected faults',loc='left',fontsize=11)
    fig.savefig(ROOT/'results'/'quantitative_results.png',dpi=180);plt.close(fig)
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='BodyCustom',fontName='BodySans',fontSize=9.5,leading=13.5,spaceAfter=9,textColor=colors.HexColor('#203845')))
    styles.add(ParagraphStyle(name='SmallCustom',fontName='BodySans',fontSize=8,leading=10.5,spaceAfter=7,textColor=colors.HexColor('#536872')))
    styles['Title'].fontName='BodySansBold';styles['Heading2'].fontName='BodySansBold'
    styles['Title'].fontSize=23;styles['Title'].leading=27;styles['Title'].alignment=TA_LEFT
    styles['Heading2'].fontSize=13;styles['Heading2'].leading=17;styles['Heading2'].textColor=colors.HexColor('#126865')
    def p(text,small=False):return Paragraph(text,styles['SmallCustom' if small else 'BodyCustom'])
    story=[p('MARIAM JAMMAL / FALL 2026 / SENIOR DESIGN',True),
           Paragraph('Image acceptance and<br/>bounded retake requests',styles['Title']),
           p('<b>Primary evaluation:</b> compare the module against technical-visibility review of original camera captures from the supplied prototype recordings. Deliberately altered copies are supporting stress tests.'),
           Paragraph('Design and intended use',styles['Heading2']),
           p('The module checks illumination, reference-relative edge strength and fine residuals. It accepts a capture, requests another attempt, or flags persistent failures. The limit is three total attempts. This supports acquisition reliability before downstream measurements. It does not determine organoid health.'),
           Paragraph('Primary dataset and results available now',styles['Heading2'])]
    data=[[p('<b>Item</b>'),p('<b>Current result or status</b>')],
          [p('Original camera data'),p('85 unmodified crops from four supplied recording files')],
          [p('Screening before human review'),p('18/85 flagged; 67/85 pass configured checks')],
          [p('Agreement with reviewer'),p('Pending actual Good/Bad/Unsure labels')],
          [p('Missed bad images and unnecessary flags'),p('Pending actual human labels; no values invented')],
          [p('Physical retakes'),p('Not yet tested on the live prototype')]]
    table=Table(data,colWidths=[220,280],hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5f0f0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.4,colors.HexColor('#d4dfe5')),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
    story+=[table,Spacer(1,8),Image(str(ROOT/'results'/'quantitative_results.png'),width=500,height=156),
            p('<b>Interpretation:</b> these are screening decisions on captured images, not confirmed detections of unusable images. Frames are correlated and some recording exports may overlap. Four files do not establish four independent experiments.',True),
            Paragraph('Complete the main evaluation',styles['Heading2']),
            p('Review the 20-image quick set in REVIEW_REAL_IMAGES.html, confirm the source attribution, and export your labels. The primary metrics will be correctly flagged bad images, missed bad images, unnecessary flags and agreement on definite labels. Unsure/unreviewed images are excluded. Freeze policy settings before labeling.'),
            p('The separate shared-Drive capture is supplemental and excluded from primary metrics because its exact prototype attribution is unconfirmed. Cropping/resizing is analysis preparation; no blur, darkness or noise was deliberately added to the primary review images.',True),
            PageBreak(),Paragraph('Supporting tests and handoff',styles['Title']),
            Paragraph('Why include stress tests?',styles['Heading2']),
            p('Controlled alterations expose specific software weaknesses. V1 missed nine noisy-blur cases because added noise increased its edge score. A residual guard corrected those listed cases. This justifies the design change, while the original captured images remain the main evaluation.'),
            p('After V2 was frozen, computational follow-up on nine additional crops accepted 27/27 controls and rejected 45/45 injected faults. Scripted sequences reached a supplied control image in 45/45 recoverable cases and escalated 18/18 persistent-failure cases. These counts are supporting engineering results, not naturally occurring faults or physical retake success.'),
            p('Follow-up controls were unchanged images, brightness scaling and mild added noise. Faults were deliberate darkness, white clipping, Gaussian blur and blur plus noise. These cases come from the same recording collection and are correlated. V2 reused the earlier benchmark during refinement.'),
            Paragraph('Source and reference requirements',styles['Heading2']),
            p('Recordings were supplied by Mariam. The review export records her confirmation that reviewed recordings came from the team prototype. Every image retains a source filename and playback timestamp. The fixed six-second references used for exploratory screening are not verified physical focus standards. Reference quality, changing scene content and real texture may affect decisions.'),
            Paragraph('Integration and next quarter',styles['Heading2']),
            p('The existing camera already handles fresh-frame timeouts and pipeline recovery. The existing scanner waits after movement. The adapter adds image-content decisions before downstream acceptance/storage. No live system was modified. Twelve behavioral tests passed, including retry bounds, cancellation and the elapsed budget.'),
            p('Next quarter, verify matched per-well/tile references, connect the adapter with the acquisition team, persist quality logs and test real retakes after controlled stage moves with a stationary bead target. Measure false acceptance, unnecessary retries, unresolved targets and time per well. Organoid-specific evaluation follows. Persistent misfocus or lighting faults require intervention.'),
            p('<b>Repository inspected:</b> khojah-lab/realtime-organoid-XYZ, commit 607a15c6c8a414e3ef3de94876b8458e8dea6b38. Integration point: services/scanner.py take_scan_photo and hardware/camera.py capture_fresh_bgr_frame. The deployed version has not been verified.',True),
            p('<b>AI assistance:</b> ChatGPT prepared code, software tests and documentation. Mariam must reproduce and explain the work, complete the real-image review and document her decisions. Coordinate the individual policy/evaluation scope with existing contributors. Instructor acceptance of the Fall deliverable remains to be confirmed.',True)]
    org=json.loads((ROOT/'results/organoid_profile_summary.json').read_text())
    story.extend([PageBreak(),Paragraph('Proposal continuity and organoid applicability',styles['Title']),
        Paragraph('Direct connection to the supplied proposal',styles['Heading2']),
        p('Page 4, Solution 4, explicitly proposes image-quality checks and reacquisition of failed captures. Section E discusses vibration and settling intervals. This module implements a bounded part of that proposal. The uploaded PDF does not independently establish its original submission date or exclusive ownership.'),
        Paragraph('Two separate evaluations of one design',styles['Heading2']),
        p('<b>Primary:</b> original bead-camera captures from the current prototype, subject to source confirmation and human review. <b>Secondary:</b> the archival organoid images supplied by Ricki, evaluated for technical image visibility and applicability with suitable references. These do not validate organoid imaging by the current prototype.'),
        p('2023 contains 18 RGB images at 800x600 pixels. 2024 contains 20 grayscale images at 4056x3040 pixels, with filenames indicating prior correction. All 38 file hashes are distinct. Raw acquisition conditions and matched focus references remain unconfirmed. Different resolution or processing does not establish better image quality.'),
        p('The organoid review is separate from biological intact/fragment annotation. Human quality labels start empty. A chosen reference must be labeled Good and reviewer-confirmed appropriate, and is excluded from the evaluation denominator. Without an appropriate reference, full gate performance remains unavailable. The tool can still export descriptive measurements and review.'),
        Paragraph('Course alignment and scope boundary',styles['Heading2']),
        p('The orientation describes individual task updates with methods, labeled data/figures, findings and next steps. Its Fall table emphasizes design/prototyping and experimental results; Winter describes organoid application. Some slides retain older year labels, so this is broad guidance rather than a verified current grading rubric.'),
        p('The screenshots show existing autofocus, stage controls, scan scheduling, storage, growth analytics and detection. The team assignments already cover lighting, training data, segmentation, scanning and model-driven control. The new claim is the specific acceptance policy and its evaluation, coordinated at an agreed acquisition interface. The general idea of defining high-quality images was already discussed by Ricki.'),
        p('The reviewed capture function does not contain this image-content policy, and the screenshots do not display an explicit acceptance/retake result. That does not rule out another branch, deployed code or work in progress. Individual ownership must be coordinated; no guarantee of zero overlap is made.'),
        Paragraph('What remains to complete the study',styles['Heading2']),
        p('Complete the bead quality review and the separate 2023/2024 organoid review. Verify source and reference assumptions. Report agreement only on actual definite reviewed labels. Use future physical tests for capture delay and real retake success. No health labels, optimal settling time or live improvement have been inferred from these saved images.'),
        p('<b>Source documents:</b> Mariam Jammal, Khojah Research Proposal (2) (1) (1).pdf, pages 3-4; 26-27 BENG 187A-D Senior Design Course Orientation.pdf, individual task template and Fall/Winter tables. See DESIGN_SCOPE_AND_EVIDENCE.md for detailed traceability.',True)])
    def footer(c,doc):
        c.setFont('BodySans',8);c.setFillColor(colors.HexColor('#637681'));c.drawString(48,28,'Engineering prototype | Software results; physical validation pending');c.drawRightString(552,28,str(doc.page))
    doc=SimpleDocTemplate(str(ROOT/'Mariam_Acquisition_Deliverable.pdf'),pagesize=(612,792),rightMargin=48,leftMargin=48,topMargin=40,bottomMargin=44)
    doc.title='Mariam - Image Acceptance and Retake Prototype'
    doc.author='Prepared for Mariam Jammal with ChatGPT assistance'
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print('Built PDF summary and quantitative figure')
if __name__=='__main__':main()
