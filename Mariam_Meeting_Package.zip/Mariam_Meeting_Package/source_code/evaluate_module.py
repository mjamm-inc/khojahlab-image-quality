"""Deterministic computational evaluation, separate from laboratory validation."""
from pathlib import Path
from dataclasses import asdict
import csv
import hashlib
import json
import time
import numpy as np
from PIL import Image,ImageFilter
from capture_quality import QualityConfig,CapturePolicy,assess,load_rgb,reference_metrics

ROOT=Path(__file__).resolve().parent

def transformations(a):
    rng=np.random.default_rng(20261124)
    def clip(x):return np.clip(np.rint(x),0,255).astype('uint8')
    blurred=np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(3)))
    return [
        ('unchanged',a,True),
        ('brightness_0.60',clip(a.astype(float)*.6),True),
        ('brightness_1.10',clip(a.astype(float)*1.1),True),
        ('noise_sigma2',clip(a+rng.normal(0,2,a.shape)),True),
        ('blur_radius1.5',np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(1.5))),False),
        ('blur_radius3',blurred,False),
        ('dark_gain0.02',clip(a.astype(float)*.02),False),
        ('clipped_white',np.full_like(a,255),False),
        ('challenge_blur3_noise8',clip(blurred+rng.normal(0,8,a.shape)),False),
    ]

def write_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def evaluate():
    config=QualityConfig()
    (ROOT/'results').mkdir(exist_ok=True)
    cases=[];sequences=[];attempts=[];runtime=[]
    demo_images={}
    for path in sorted((ROOT/'sources').glob('clip*.png')):
        a=load_rgb(path)
        split='development' if path.name.startswith('clip1_') else 'held_out'
        ref=reference_metrics(a,config)
        conditions=transformations(a)
        images={name:b for name,b,expected in conditions}
        images['missing']=None
        for name,b,expected in conditions:
            start=time.perf_counter();result=assess(b,ref,config);runtime.append(time.perf_counter()-start)
            cases.append(dict(source=path.name,split=split,condition=name,
                              expected_pass=int(expected),observed_pass=int(result['passed']),
                              reasons=';'.join(result['reasons']),**result['metrics']))
        if path.name=='clip2_09s.png':
            demo_dir=ROOT/'demo_images';demo_dir.mkdir(exist_ok=True)
            for name,b,expected in conditions:
                Image.fromarray(b).save(demo_dir/(name+'.png'))
        if split!='held_out':continue
        patterns=[['unchanged'],['blur_radius3','unchanged'],['dark_gain0.02','unchanged'],
                  ['missing','blur_radius3','unchanged'],
                  ['dark_gain0.02']*3,['blur_radius3','dark_gain0.02','missing'],
                  ['challenge_blur3_noise8','unchanged']]
        truth={name:expected for name,b,expected in conditions};truth['missing']=False
        for index,pattern in enumerate(patterns):
            policy=CapturePolicy(a,f'{path.stem}_sequence{index+1}',config)
            for i,name in enumerate(pattern):
                row=policy.evaluate(images[name],i*.5)
                flat={k:v for k,v in row.items() if k not in ['metrics','reasons']}
                attempts.append(dict(source=path.name,sequence=index+1,input_condition=name,
                                     reasons=';'.join(row['reasons']),**flat,**row['metrics']))
                if policy.finished:break
            sequences.append(dict(source=path.name,sequence=index+1,
                                  pattern=' / '.join(pattern),attempts=len(policy.history),
                                  baseline_first_pass=int(truth[pattern[0]]),
                                  controller_accepted=int(row['decision']=='ACCEPT'),
                                  controller_accepted_expected_good=int(row['decision']=='ACCEPT' and truth[name]),
                                  controller_false_accept=int(row['decision']=='ACCEPT' and not truth[name]),
                                  final_decision=row['decision']))
    held=[r for r in cases if r['split']=='held_out']
    good=[r for r in held if r['expected_pass']]
    bad=[r for r in held if not r['expected_pass']]
    ordinary_bad=[r for r in bad if not r['condition'].startswith('challenge')]
    challenge=[r for r in bad if r['condition'].startswith('challenge')]
    summary=dict(scope='Computational fault injection on real archived bead-camera crops. Ground truth is transform class, not human-rated biological usability.',
                 fixed_config=asdict(config),threshold_selection='V1 constants were set before initial evaluation. V2 adds a residual guard after observing V1 noise failures. The benchmark is reused for development evaluation and is NOT an independent final validation set.',
                 source_crops=12,source_recording_files=4,development_cases=len(cases)-len(held),held_out_cases=len(held),
                 source_split='clip1 development, clips2/3/4 held out. Files are not verified independent acquisitions.',
                 acceptable_control_cases=len(good),acceptable_controls_accepted=sum(r['observed_pass'] for r in good),
                 injected_fault_cases=len(bad),injected_faults_rejected=sum(not r['observed_pass'] for r in bad),
                 ordinary_fault_cases=len(ordinary_bad),ordinary_faults_rejected=sum(not r['observed_pass'] for r in ordinary_bad),
                 noisy_blur_challenge_cases=len(challenge),noisy_blur_challenges_rejected=sum(not r['observed_pass'] for r in challenge),
                 sequences=len(sequences),baseline_good_first_captures=sum(r['baseline_first_pass'] for r in sequences),
                 controller_good_final_captures=sum(r['controller_accepted_expected_good'] for r in sequences),
                 controller_false_accepts=sum(r['controller_false_accept'] for r in sequences),
                 controller_escalations=sum(r['final_decision']=='ESCALATE' for r in sequences),
                 total_controller_attempts=sum(r['attempts'] for r in sequences),
                 processing_ms_median_this_computer=float(np.median(runtime)*1000),
                 biological_validation='Not performed',human_review='Not completed',hardware_integration='Adapter supplied, not deployed or verified on Raspberry Pi')
    write_csv(ROOT/'results'/'fault_injection_cases.csv',cases)
    write_csv(ROOT/'results'/'sequence_summary.csv',sequences)
    # Attempts have heterogeneous metric keys for missing frames. Normalize before CSV.
    keys=list(dict.fromkeys(k for row in attempts for k in row))
    write_csv(ROOT/'results'/'attempt_log.csv',[{k:r.get(k,'') for k in keys} for r in attempts])
    (ROOT/'results'/'summary.json').write_text(json.dumps(summary,indent=2))
    (ROOT/'source_manifest.json').write_text(json.dumps([dict(file=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((ROOT/'sources').glob('*')) if p.is_file()],indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':evaluate()
