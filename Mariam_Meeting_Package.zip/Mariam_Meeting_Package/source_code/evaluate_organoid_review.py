"""Recompute organoid review agreement from stored Python features and actual labels.
Does not trust the browser-exported predictions or counts. References are reviewer
confirmed inputs, not automatically verified biological/optical standards.
"""
from pathlib import Path
import argparse,json
from capture_quality import QualityConfig
ROOT=Path(__file__).resolve().parent

def evaluate_record(row,reference,config):
    m=row['metrics'];b=reference['metrics'];reasons=[]
    if b['mean_gray']<config.min_mean or b['mean_gray']>config.max_mean or b['white_fraction']>config.max_white_fraction or b['normalized_edge']<1e-9:
        return None,['INVALID_REFERENCE']
    if row['width']!=reference['width'] or row['height']!=reference['height']:
        return None,['REFERENCE_DIMENSION_MISMATCH']
    if m['mean_gray']<config.min_mean:reasons.append('LOW_LIGHT')
    if m['mean_gray']>config.max_mean or m['white_fraction']>config.max_white_fraction:reasons.append('OVEREXPOSED')
    if m['normalized_edge']/b['normalized_edge']<config.min_relative_edge:reasons.append('LOW_RELATIVE_EDGE')
    if m['fine_residual']>max(config.max_residual_floor,config.max_residual_reference_factor*b['fine_residual']):reasons.append('EXCESS_FINE_RESIDUAL')
    return not reasons,reasons

def main():
    p=argparse.ArgumentParser();p.add_argument('review',type=Path);args=p.parse_args()
    review=json.loads(args.review.read_text())
    if not str(review.get('reviewer','')).strip():raise ValueError('Reviewer name required')
    inventory={r['id']:r for r in json.loads((ROOT/'results/organoid_inventory_metrics.json').read_text())}
    labels={}
    for r in review['records']:
        if r['id'] not in inventory or r['id'] in labels:raise ValueError('Unknown or duplicate image')
        if r['label'] not in ['good','bad','unsure']:raise ValueError('Invalid review label')
        if r['sha256']!=inventory[r['id']]['sha256']:raise ValueError('Original image hash mismatch')
        labels[r['id']]=r
    summaries=[]
    for year in ['2023','2024']:
        reference_input=review.get('references',{}).get(year,{})
        reference=inventory.get(reference_input.get('id'))
        eligible=reference is not None and reference['year']==year and reference_input.get('reviewer_confirmed_matching') is True and labels.get(reference['id'],{}).get('label')=='good'
        tp=tn=fp=fn=unsure=unavailable=calibration=0
        for id,label in labels.items():
            row=inventory[id]
            if row['year']!=year:continue
            if not eligible:unavailable+=1;continue
            if id==reference['id']:calibration+=1;continue
            passed,reasons=evaluate_record(row,reference,QualityConfig())
            if passed is None:unavailable+=1;continue
            if label['label']=='unsure':unsure+=1;continue
            bad=label['label']=='bad'
            tp+=int(bad and not passed);tn+=int(not bad and passed)
            fp+=int(not bad and not passed);fn+=int(bad and passed)
        n=tp+tn+fp+fn
        summaries.append(dict(cohort=year,definite_evaluable_images=n,correctly_flagged_bad=tp,
                              correctly_passed_good=tn,unnecessary_flags=fp,missed_bad_images=fn,
                              unsure_excluded=unsure,reference_unavailable=unavailable,
                              calibration_references_excluded=calibration,
                              agreement_percent=100*(tp+tn)/n if n else None))
    result=dict(reviewer=review['reviewer'],cohort_results=summaries,
                scope='Exploratory archival-organoid applicability. Not current-prototype organoid capture, independent validation or health assessment.',
                reference_context=review.get('reference_context',''))
    (ROOT/'results/organoid_human_review_summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
