"""Recompute recent-image review counts using stored source measurements."""
from pathlib import Path
import argparse,json
from capture_quality import QualityConfig
ROOT=Path(__file__).resolve().parent

def decision(r,inventory,labels,references):
    if r['illumination_reasons']:return False,'FLAG'
    context=references.get(r['group'],{});ref=inventory.get(context.get('id'))
    if context.get('verified') is not True or not ref or ref['group']!=r['group'] or labels.get(ref['id'],{}).get('label')!='good':return None,'REFERENCE_REQUIRED'
    if ref['id']==r['id']:return None,'CALIBRATION_REFERENCE'
    if ref['illumination_reasons'] or ref['metrics']['normalized_edge']<1e-9:return None,'REFERENCE_REQUIRED'
    cfg=QualityConfig();m=r['metrics'];b=ref['metrics']
    passed=m['normalized_edge']/b['normalized_edge']>=cfg.min_relative_edge and m['fine_residual']<=max(cfg.max_residual_floor,cfg.max_residual_reference_factor*b['fine_residual'])
    return bool(passed),'PASSES_CONFIGURED_CHECKS' if passed else 'FLAG'

def main():
    p=argparse.ArgumentParser();p.add_argument('review',type=Path);args=p.parse_args();review=json.loads(args.review.read_text())
    if not str(review.get('reviewer','')).strip():raise ValueError('Reviewer required')
    inventory={r['id']:r for r in json.loads((ROOT/'results/recent_bead_inventory_metrics.json').read_text())}
    labels={}
    for r in review['records']:
        if r['id'] not in inventory or r['id'] in labels or r['sha256']!=inventory[r['id']]['sha256']:raise ValueError('Unknown, duplicate or mismatched original image')
        if r['label'] not in ['good','bad','unsure']:raise ValueError('Invalid label')
        labels[r['id']]=r
    light=dict(definite_labels=0,flagged_bad=0,unflagged_good=0,unnecessary_flags=0,unflagged_bad=0)
    full=dict(definite_evaluable_images=0,flagged_bad=0,passed_good=0,unnecessary_flags=0,missed_bad=0,reference_unavailable=0,calibration_excluded=0,unsure_excluded=0)
    for id,l in labels.items():
        if l['label']=='unsure':full['unsure_excluded']+=1;continue
        r=inventory[id];bad=l['label']=='bad';flag=bool(r['illumination_reasons']);light['definite_labels']+=1
        light['flagged_bad']+=int(bad and flag);light['unflagged_good']+=int(not bad and not flag)
        light['unnecessary_flags']+=int(not bad and flag);light['unflagged_bad']+=int(bad and not flag)
        passed,status=decision(r,inventory,labels,review.get('references',{}))
        if status=='CALIBRATION_REFERENCE':full['calibration_excluded']+=1;continue
        if passed is None:full['reference_unavailable']+=1;continue
        full['definite_evaluable_images']+=1;full['flagged_bad']+=int(bad and not passed);full['passed_good']+=int(not bad and passed)
        full['unnecessary_flags']+=int(not bad and not passed);full['missed_bad']+=int(bad and passed)
    light['agreement_percent']=100*(light['flagged_bad']+light['unflagged_good'])/light['definite_labels'] if light['definite_labels'] else None
    light['scope']='Illumination component versus overall technical labels; does not establish full-policy acceptance.'
    full['agreement_percent']=100*(full['flagged_bad']+full['passed_good'])/full['definite_evaluable_images'] if full['definite_evaluable_images'] else None
    result=dict(reviewer=review['reviewer'],source_confirmation=review.get('source_confirmation','unconfirmed'),illumination_component=light,reference_aware_policy=full,scope='Reviewed subset of correlated original prototype images. No physical retake or settling-time result.')
    (ROOT/'results/recent_bead_human_review_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
