"""Calculate agreement from actual exported human labels and stored gate outputs."""
from pathlib import Path
import argparse,json
ROOT=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('review',type=Path);args=p.parse_args()
    review=json.loads(args.review.read_text())
    if not isinstance(review.get('reviewer'),str) or not review['reviewer'].strip():
        raise ValueError('Reviewer name is required')
    outputs={r['id']:r for r in json.loads((ROOT/'results'/'archive_review.json').read_text())}
    seen=set();tp=tn=fp=fn=unsure=0
    for r in review['records']:
        if r['id'] in seen or r['id'] not in outputs:raise ValueError('Duplicate or unknown image ID')
        seen.add(r['id']);label=r['label']
        if label not in {'good','bad','unsure'}:raise ValueError('Invalid human label')
        if r['id']=='nov21_camera.jpg':continue  # supplemental, exact prototype unconfirmed
        if label=='unsure':unsure+=1;continue
        passed=outputs[r['id']]['gate_pass']
        tp+=int(label=='bad' and not passed);tn+=int(label=='good' and passed)
        fp+=int(label=='good' and not passed);fn+=int(label=='bad' and passed)
    n=tp+tn+fp+fn
    result=dict(reviewer=review['reviewer'],source_confirmation=review.get('source_confirmation','unconfirmed'),
                excluded_from_primary=['nov21_camera.jpg'],definite_labels=n,unsure_labels=unsure,
                correctly_flagged_bad=tp,correctly_passed_good=tn,
                unnecessary_flags=fp,missed_bad_inputs=fn,
                agreement_percent=100*(tp+tn)/n if n else None,
                bad_image_recall=tp/(tp+fn) if tp+fn else None,
                flag_precision=tp/(tp+fp) if tp+fp else None,
                scope='Provisional technical-visibility review on correlated archived bead images. Not independent organoid validation.')
    path=ROOT/'results'/'human_review_summary.json';path.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
