"""Frozen V2 follow-up on new timestamps, still from the same recording collection."""
from pathlib import Path
from dataclasses import asdict
import json
import numpy as np
from PIL import Image,ImageFilter
from capture_quality import *
from evaluate_module import write_csv

ROOT=Path(__file__).resolve().parent
def main():
    rows=[];excluded=[];config=QualityConfig()
    for index,path in enumerate(sorted((ROOT/'sources').glob('validation_*.png'))):
        a=load_rgb(path)
        try:ref=reference_metrics(a,config)
        except ValueError as exc:
            excluded.append(dict(source=path.name,reason=str(exc)));continue
        rng=np.random.default_rng(11000+index)
        def clip(x):return np.clip(np.rint(x),0,255).astype('uint8')
        blur=np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(4)))
        cases=[('unchanged',a,True),('brightness_0.70',clip(a.astype(float)*.7),True),
               ('noise_sigma2',clip(a+rng.normal(0,2,a.shape)),True),
               ('dark_gain0.02',clip(a.astype(float)*.02),False),
               ('clipped_white',np.full_like(a,255),False),
               ('blur_radius2',np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(2))),False),
               ('blur_radius4',blur,False),
               ('challenge_blur4_noise7',clip(blur+rng.normal(0,7,a.shape)),False)]
        for name,b,expected in cases:
            result=assess(b,ref,config)
            rows.append(dict(source=path.name,condition=name,expected_pass=int(expected),
                             observed_pass=int(result['passed']),reasons=';'.join(result['reasons']),**result['metrics']))
    good=[r for r in rows if r['expected_pass']];bad=[r for r in rows if not r['expected_pass']]
    summary=dict(scope='Frozen-policy computational follow-up. New timestamps and selected transform settings after V2 freeze. Same recordings as development, so not independent physical/biological validation.',
                 config=asdict(config),source_crops=len(set(r['source'] for r in rows)),excluded=excluded,
                 total_cases=len(rows),acceptable_control_cases=len(good),acceptable_controls_accepted=sum(r['observed_pass'] for r in good),
                 injected_fault_cases=len(bad),injected_faults_rejected=sum(not r['observed_pass'] for r in bad))
    write_csv(ROOT/'results'/'followup_cases.csv',rows)
    (ROOT/'results'/'followup_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
