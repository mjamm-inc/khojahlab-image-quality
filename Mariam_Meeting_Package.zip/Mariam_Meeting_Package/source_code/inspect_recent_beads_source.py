from pathlib import Path,PurePosixPath
from collections import Counter,defaultdict
import zipfile,json,hashlib,sys,io,re,csv
import numpy as np
from PIL import Image,ImageOps,ImageDraw
sys.path.insert(0,str(Path(__file__).resolve().parent))
from capture_quality import metrics,QualityConfig
import argparse
parser=argparse.ArgumentParser(description='Reproduce original recent-bead ZIP inventory and measurements.')
parser.add_argument('--archives',type=Path,required=True)
parser.add_argument('--output',type=Path,default=Path('recent_bead_source_cache'))
args=parser.parse_args()
root=args.output;root.mkdir(exist_ok=True,parents=True)
rows=[];archive_summary=[]
for archive in sorted(args.archives.glob('2026-11-*-20261124*.zip')):
 count=0
 with zipfile.ZipFile(archive) as z:
  for member in z.infolist():
   parts=PurePosixPath(member.filename).parts
   if member.is_dir() or Path(member.filename).suffix.lower() not in {'.jpg','.jpeg','.png'} or '__MACOSX' in parts:continue
   if '..' in parts or PurePosixPath(member.filename).is_absolute():raise ValueError('Unsafe member path')
   raw=z.read(member);p=root.joinpath(*parts);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
   with Image.open(io.BytesIO(raw)) as im:
    im.load();a=np.asarray(im.convert('RGB'));width,height=im.size;mode=im.mode
   measurement=metrics(a)
   low=measurement['mean_gray']<20;high=measurement['mean_gray']>235 or measurement['white_fraction']>.2
   match=re.fullmatch(r'(.+)_(\d{8})_(\d{6})',p.stem)
   day=parts[0];well=match.group(1) if match else (parts[1] if len(parts)>1 else 'unknown')
   timestamp=f'{match.group(2)[:4]}-{match.group(2)[4:6]}-{match.group(2)[6:]}T{match.group(3)[:2]}:{match.group(3)[2:4]}:{match.group(3)[4:]}' if match else None
   rows.append(dict(id=member.filename,archive=archive.name,path=str(p),day=day,well=well,filename_timestamp_local_unverified=timestamp,width=width,height=height,mode=mode,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),pixel_sha256=hashlib.sha256(a.tobytes()).hexdigest(),metrics=measurement,illumination_reasons=['LOW_LIGHT'] if low else ['OVEREXPOSED'] if high else [],human_label=None,reference_status='UNCONFIRMED',current_gate_scope='Absolute illumination screen only. Relative detail checks require a suitable matched reference.'))
   count+=1
 archive_summary.append(dict(archive=archive.name,image_files=count))
if not rows:raise ValueError('No recent bead images found in matching supplied ZIP archives')
rows.sort(key=lambda x:(x['day'],x['well'],x['filename_timestamp_local_unverified'] or x['id']))
(root/'inventory_metrics.json').write_text(json.dumps(rows,indent=2))
summary={'image_files':len(rows),'archive_files':len(archive_summary),'nonempty_archives':sum(x['image_files']>0 for x in archive_summary),'archive_counts':archive_summary,'native_dimensions':dict(Counter(f"{r['width']}x{r['height']}" for r in rows)),'file_hashes_unique':len({r['sha256'] for r in rows}),'pixel_hashes_unique':len({r['pixel_sha256'] for r in rows}),'provisional_low_light_flags':sum('LOW_LIGHT' in r['illumination_reasons'] for r in rows),'provisional_overexposure_flags':sum('OVEREXPOSED' in r['illumination_reasons'] for r in rows),'median_brightness':float(np.median([r['metrics']['mean_gray'] for r in rows])),'day_well_groups':len({(r['day'],r['well']) for r in rows}),'by_day':{d:dict(images=sum(r['day']==d for r in rows),low_light_flags=sum(r['day']==d and 'LOW_LIGHT' in r['illumination_reasons'] for r in rows)) for d in sorted({r['day'] for r in rows})},'limitations':'Image counts are available files, not uptime or missing-image rate. Timestamp time zone and acquisition settings not independently verified. No human reference labels or matched focus references supplied.'}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
# One unmodified middle-timestamp sample per day/well for internal inspection only.
groups=defaultdict(list)
for r in rows:groups[r['day'],r['well']].append(r)
selected=[v[len(v)//2] for k,v in sorted(groups.items())]
sheet=Image.new('RGB',(6*200,((len(selected)+5)//6)*225),'white');draw=ImageDraw.Draw(sheet)
for i,r in enumerate(selected):
 with Image.open(r['path']) as im:thumb=ImageOps.contain(im.convert('RGB'),(194,190))
 x=(i%6)*200;y=(i//6)*225;sheet.paste(thumb,(x,y));draw.text((x+2,y+192),r['day']+' '+r['well'],fill='black');draw.text((x+2,y+207),'mean '+str(round(r['metrics']['mean_gray'],1)),fill='black')
sheet.save(root/'contact_sheet.jpg')
