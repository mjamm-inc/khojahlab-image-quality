"""Integration example for the reviewed lab scanner. Not deployed.

Call only while the existing scanner owns a stationary stage at the intended
well/tile. Store the returned accepted BGR image using the existing storage manager.
Keep raw failures/logs separately. Never turn failed attempts into successful captures.
"""
from capture_quality import QualityConfig,run_capture_cycle

def capture_checked_bgr(reference_bgr,capture_id,cancel,roi=None,config=QualityConfig()):
    # Deferred import prevents hardware initialization when this module is inspected.
    from hardware.camera import capture_fresh_bgr_frame
    def fresh_rgb():
        # max_age_sec=0 waits for a new stream sequence instead of reusing a recent frame.
        frame=capture_fresh_bgr_frame(max_age_sec=0.0,
                                      wait_timeout_sec=min(2.0,config.max_elapsed_s))
        return None if frame is None else frame[:,:,::-1].copy()
    accepted_rgb,history=run_capture_cycle(fresh_rgb,reference_bgr[:,:,::-1].copy(),
        capture_id,config,roi,cancel_fn=cancel.is_set)
    accepted_bgr=None if accepted_rgb is None else accepted_rgb[:,:,::-1].copy()
    return accepted_bgr,history
