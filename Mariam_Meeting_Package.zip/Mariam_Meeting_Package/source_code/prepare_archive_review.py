"""Reconstruct the earlier 85-frame sample and emit provisional gate decisions.
Requires ffmpeg and original recordings under the provided directory. Review labels
start empty. Nothing here generates human ground truth.
"""
from pathlib import Path
import argparse,csv,json,re,subprocess
import numpy as np
from PIL import Image
from capture_quality import *

ROOT=Path(__file__).resolve().parent
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--recordings',type=Path,required=True)
    args=parser.parse_args();rows=[]
    out=ROOT/'archive_frames';out.mkdir(exist_ok=True)
    names=['bead_motor_recording_1.mp4','bead_motor_recording_2.mp4','bead_motor_recording_4.mp4','Main Bead Recordng - 10:28.mov']
    for idx,name in enumerate(names,1):
        path=args.recordings/name
        dur=float(subprocess.check_output(['ffprobe','-v','quiet','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]))
        crop='900:900:150:600' if idx<4 else '900:900:150:150'
        proc=subprocess.run(['ffmpeg','-v','info','-i',str(path),'-vf',f'select=not(mod(n\\,60)),showinfo,crop={crop},scale=256:256','-vsync','0','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True)
        frames=np.frombuffer(proc.stdout,dtype='uint8').reshape(-1,256,256,3)[:int(dur)]
        times=[float(v) for v in re.findall(r'pts_time:([0-9.]+)',proc.stderr.decode())][:int(dur)]
        # Predetermined 6-second reference; NOT a verified focus standard.
        ref=reference_metrics(load_rgb(ROOT/'sources'/f'clip{idx}_06s.png'))
        for j,(a,t) in enumerate(zip(frames,times)):
            filename=f'archive_clip{idx}_{j:02d}.png';Image.fromarray(a).save(out/filename)
            result=assess(a,ref)
            rows.append(dict(id=filename,source=name,timestamp_s=t,
                             gate_pass=result['passed'],reasons=result['reasons'],
                             metrics=result['metrics'],human_label=None))
    recent=load_rgb(ROOT/'sources'/'nov21_camera.jpg')
    ref=reference_metrics(load_rgb(ROOT/'sources'/'clip2_09s.png'))
    r=assess(recent,ref)
    rows.append(dict(id='nov21_camera.jpg',source='Shared Drive top_right_20261121_125654.jpg',timestamp_s=None,
                     gate_pass=r['passed'],reasons=r['reasons'],metrics=r['metrics'],human_label=None))
    (ROOT/'results'/'archive_review.json').write_text(json.dumps(rows,indent=2))
    print('Prepared',len(rows),'real archived inputs. Human labels remain empty.')
if __name__=='__main__':main()
