"""Measure as-provided PNGs in the two supplied ZIPs and build review previews.
Requires only the core packages. Original PNG bytes are preserved in source_cache.
The ZIPs are user-supplied archival material, not generated experimental data.
"""
from pathlib import Path
from dataclasses import asdict
import argparse,csv,hashlib,json,zipfile
import numpy as np
from PIL import Image,ImageOps
from capture_quality import QualityConfig,load_rgb,metrics
ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--zip2023',type=Path,required=True)
    parser.add_argument('--zip2024',type=Path,required=True)
    parser.add_argument('--original2024',type=Path,help='Optional supplied original 2024 JPG archive; keeps corrected versions separate')
    args=parser.parse_args();rows=[]
    cache=ROOT/'source_cache';previews=ROOT/'organoid_previews';previews.mkdir(exist_ok=True)
    inputs=[('2023',args.zip2023,'as_provided'),('2024',args.zip2024,'corrected' if args.original2024 else 'as_provided')]
    if args.original2024:inputs.append(('2024',args.original2024,'original'))
    for year,path,role in inputs:
        seen=set()
        with zipfile.ZipFile(path) as archive:
            members=[m for m in archive.infolist() if not m.is_dir() and Path(m.filename).suffix.lower() in {'.png','.jpg','.jpeg'}]
            if sum(m.file_size for m in members)>500_000_000:raise ValueError('Image archive too large for this workflow')
            for member in members:
                name=Path(member.filename).name
                if name in seen:raise ValueError('Duplicate image filename in cohort')
                seen.add(name);raw=archive.read(member);target=cache/(year+'_original' if role=='original' else year)/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
                with Image.open(target) as image:
                    row=dict(id=year+'/'+name,year=year,width=image.width,height=image.height,mode=image.mode,
                             sha256=hashlib.sha256(raw).hexdigest(),processing_role=role,provided_processing='User supplied as original; acquisition metadata unverified' if role=='original' else 'filename indicates corrected image' if 'corrected' in name.lower() else 'unknown',
                             source_attribution='Archival organoid images supplied by Ricki; exact microscope/acquisition protocol not confirmed')
                    preview=previews/(year+'_'+Path(name).stem+'.jpg')
                    ImageOps.contain(image.convert('RGB'),(1000,750)).save(preview,quality=92)
                row.update(metrics=metrics(load_rgb(target)),label=None,preview=str(preview.relative_to(ROOT)))
                rows.append(row)
    rows.sort(key=lambda x:x['id'])
    corrected=[r for r in rows if r.get('processing_role')=='corrected']
    if corrected:(ROOT/'results/organoid_corrected_inventory_metrics.json').write_text(json.dumps(corrected,indent=2))
    rows=[r for r in rows if r.get('processing_role')!='corrected']
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/organoid_inventory_metrics.json').write_text(json.dumps(rows,indent=2))
    flat=[{k:r[k] for k in ['id','year','width','height','mode','sha256','provided_processing']}|r['metrics'] for r in rows]
    with (ROOT/'results/organoid_image_metrics.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
    summary={}
    for year in ['2023','2024']:
        subset=[r for r in rows if r['year']==year];means=[r['metrics']['mean_gray'] for r in subset]
        summary[year]=dict(images=len(subset),native_dimensions=sorted({(r['width'],r['height']) for r in subset}),
                           modes=sorted({r['mode'] for r in subset}),median_brightness=float(np.median(means)),
                           mean_brightness_range=[min(means),max(means)],
                           median_normalized_edge=float(np.median([r['metrics']['normalized_edge'] for r in subset])))
    summary.update(scope='Descriptive measurements on as-provided archival organoid images. Corrected 2024 versions, when supplied with originals, are kept separately. Human labels and verified references are pending. No biological interpretation.',config=asdict(QualityConfig()))
    (ROOT/'results/organoid_profile_summary.json').write_text(json.dumps(summary,indent=2))
    print('Measured',len(rows),'archival inputs. To build review: python3 build_organoid_review.py')

if __name__=='__main__':main()
