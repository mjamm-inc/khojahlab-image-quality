"""Behavioral tests for bounded capture retries and failure handling."""
from dataclasses import replace
from pathlib import Path
import sys
import unittest
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from capture_quality import CapturePolicy,QualityConfig,load_rgb,run_capture_cycle

class PolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference=load_rgb(Path(__file__).resolve().parents[1]/'sources'/'clip2_09s.png')

    def test_accept_closes_cycle(self):
        p=CapturePolicy(self.reference,'wellA/time1')
        self.assertEqual(p.evaluate(self.reference,0)['decision'],'ACCEPT')
        with self.assertRaises(RuntimeError):p.evaluate(self.reference,1)

    def test_three_failures_escalate_without_unbounded_retry(self):
        p=CapturePolicy(self.reference,'wellA/time2')
        decisions=[p.evaluate(np.zeros_like(self.reference),t)['decision'] for t in [0,.5,1]]
        self.assertEqual(decisions,['RETRY','RETRY','ESCALATE'])
        self.assertTrue(p.finished)

    def test_missing_frame_can_recover(self):
        frames=iter([None,self.reference])
        accepted,log=run_capture_cycle(lambda:next(frames),self.reference,'wellA/time3')
        self.assertEqual([x['decision'] for x in log],['RETRY','ACCEPT'])
        self.assertIs(accepted,self.reference)

    def test_invalid_reference_cannot_produce_accept(self):
        with self.assertRaises(ValueError):CapturePolicy(np.zeros_like(self.reference),'badref')
        with self.assertRaises(ValueError):CapturePolicy(np.full_like(self.reference,120),'flatref')

    def test_different_resolution_requires_new_reference(self):
        p=CapturePolicy(self.reference,'shape')
        row=p.evaluate(self.reference[:128],0)
        self.assertEqual(row['reasons'],['REFERENCE_SHAPE_MISMATCH'])
        self.assertEqual(row['decision'],'RETRY')

    def test_capture_exceptions_escalate(self):
        def fail():raise OSError('unavailable')
        accepted,log=run_capture_cycle(fail,self.reference,'failure')
        self.assertIsNone(accepted)
        self.assertEqual(len(log),3)
        self.assertEqual(log[-1]['decision'],'ESCALATE')

    def test_expired_budget_never_accepts_late_good_image(self):
        p=CapturePolicy(self.reference,'timeout',replace(QualityConfig(),max_elapsed_s=1))
        row=p.evaluate(self.reference,1.1)
        self.assertEqual(row['decision'],'ESCALATE')
        self.assertFalse(row['passed'])

    def test_cancel_never_calls_camera(self):
        def forbidden():raise AssertionError('Camera should not be called')
        accepted,log=run_capture_cycle(forbidden,self.reference,'cancel',cancel_fn=lambda:True)
        self.assertIsNone(accepted)
        self.assertEqual(log[-1]['decision'],'CANCELLED')

    def test_time_and_config_validation(self):
        with self.assertRaises(ValueError):QualityConfig(max_attempts=0)
        p=CapturePolicy(self.reference,'time')
        with self.assertRaises(ValueError):p.evaluate(None,float('nan'))
        p.evaluate(None,.5)
        with self.assertRaises(ValueError):p.evaluate(None,.4)

    def test_noise_does_not_rescue_known_blur_challenge(self):
        from PIL import Image,ImageFilter
        blurred=np.asarray(Image.fromarray(self.reference).filter(ImageFilter.GaussianBlur(3)))
        noisy=np.clip(blurred+np.random.default_rng(77).normal(0,8,blurred.shape),0,255).astype('uint8')
        row=CapturePolicy(self.reference,'noisyblur').evaluate(noisy,0)
        self.assertEqual(row['decision'],'RETRY')
        self.assertIn('EXCESS_FINE_RESIDUAL',row['reasons'])

    def test_expired_budget_prevents_camera_call(self):
        def forbidden():raise AssertionError('Camera should not be called after deadline')
        ticks=iter([0,2,2])
        accepted,log=run_capture_cycle(forbidden,self.reference,'expired',
            replace(QualityConfig(),max_elapsed_s=1),clock=lambda:next(ticks))
        self.assertIsNone(accepted)
        self.assertEqual(log[-1]['decision'],'ESCALATE')

    def test_rectangular_organoid_images_keep_aspect_ratio(self):
        from capture_quality import metrics
        image=np.tile(self.reference,(3,4,1))
        m=metrics(image)
        self.assertEqual((m['analysis_width'],m['analysis_height']),(256,192))

if __name__=='__main__':unittest.main()
